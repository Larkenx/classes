Properties Altered (differing from guide material):

Project ONE:
	formProjectOne:
	CancelButton: btnQuit
	AcceptButton: btnSelectPicture
	BackColor: Honeydew

	picShowPicure:
	Anchor: Top, Bottom, Left, Right
	SizeMode: StretchImage

	btnEnlarge/Shrink:
	Font: 12pt (from 8pt)
	Cursor: Hand

	btnSelectPicture:
	Cursor: Hand

	btnDrawBorder:
	Cursor: Hand

	lblX:
	Font>Italic: True

	lblY:
	Font>Italic: True

Project TWO:
	All buttons have "Hand" cursors to mimic the design of project one. FormOptions and FormCollections both
	have icons for their forms. I also adjusted the text alignment in FormCollections for the textbox.
