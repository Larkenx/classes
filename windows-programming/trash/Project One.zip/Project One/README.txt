Properties Altered (differing from guide material):

formProjectOne:
CancelButton: btnQuit
AcceptButton: btnSelectPicture
BackColor: Honeydew

picShowPicure:
Anchor: Top, Bottom, Left, Right
SizeMode: StretchImage

btnEnlarge/Shrink:
Font: 12pt (from 8pt)
Cursor: Hand

btnSelectPicture:
Cursor: Hand

btnDrawBorder:
Cursor: Hand

lblX:
Font>Italic: True

lblY:
Font>Italic: True
